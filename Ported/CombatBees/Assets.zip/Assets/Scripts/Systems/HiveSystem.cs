using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

[BurstCompile]
partial struct HiveSystem : ISystem
{
    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
    }

    [BurstCompile]
    public void OnDestroy(ref SystemState state)
    {
    }

    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        foreach (var (hive, hiveTeam) in SystemAPI.Query<RefRW<Hive>, Team>())
        {
            uint whichTeamIsEnemy = (uint)(hiveTeam.number == 0 ? 1 : 0);
            Team enemyTeam = new Team { number = whichTeamIsEnemy };

            Debug.LogWarning(enemyTeam.number);

            //hive.ValueRW.enemyBees.Clear();
            //hive.ValueRW.resources.Clear();

            foreach (var (beeState, entity) in SystemAPI.Query<BeeState>().WithEntityAccess().WithSharedComponentFilter(enemyTeam))
            {
                hive.ValueRW.enemyBees.Add(entity);
                Debug.LogWarning(enemyTeam.number);
            }

            // For resources, pretty much same as above, but without shared components
        }
    }
}