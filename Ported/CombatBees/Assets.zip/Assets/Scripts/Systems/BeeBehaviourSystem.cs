using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

[BurstCompile]
partial struct BeeBehaviourSystem : ISystem
{
    Entity target;

    [BurstCompile]
    public void OnCreate(ref SystemState state)
    {
    }

    [BurstCompile]
    public void OnDestroy(ref SystemState state)
    {
    }

    [BurstCompile]
    public void OnUpdate(ref SystemState state)
    {
        /*EntityCommandBuffer ecb = new EntityCommandBuffer(Unity.Collections.Allocator.TempJob);
        EntityCommandBuffer.ParallelWriter parallelEcb = ecb.AsParallelWriter();*/
        //parallelEcb.set
        
        
        // The amount of rotation around Y required to do 360 degrees in 2 seconds.
        var rotation = quaternion.RotateY(SystemAPI.Time.DeltaTime * math.PI);

        foreach (var (transform, beeState, team, entity) in SystemAPI.Query<TransformAspect, RefRW<BeeState>, Team>().WithEntityAccess())
        {
            switch (beeState.ValueRO.beeState)
            {
                case BeeStateEnumerator.Attacking:
                    //
                    break;
                case BeeStateEnumerator.Gathering:
                    //
                    break;
                case BeeStateEnumerator.CarryBack:
                    //
                    break;
                case BeeStateEnumerator.Dying:
                    //
                    break;
            }

            //em.SetComponentData(entity, new BeeState { beeState = (BeeStateEnumerator)UnityEngine.Random.Range(0, 3) });

            transform.RotateLocal(rotation);
            //parallelEcb.SetComponent<BeeState>(entity, new BeeState { beeState = (BeeStateEnumerator)UnityEngine.Random.Range(0, 3) };)
        }
    }
}