﻿using Unity.Entities;

public struct Team : ISharedComponentData
{
   public uint number;
}