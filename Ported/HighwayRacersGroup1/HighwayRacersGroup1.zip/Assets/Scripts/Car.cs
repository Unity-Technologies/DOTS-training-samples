using UnityEngine;

public class Car : MonoBehaviour
{
    public int SegmentID;
    public float SegmentDistance;
    public float lane;

    public void Update()
    {
        //transform.localPosition += Direction * Time.deltaTime;
    }
}