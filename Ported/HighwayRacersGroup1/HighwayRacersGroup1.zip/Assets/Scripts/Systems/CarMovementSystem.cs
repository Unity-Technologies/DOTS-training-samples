using System;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;

partial struct CarMovementSystem : ISystem
{
    private EntityQuery trackSegments;

    // Every function defined by ISystem has to be implemented even if empty.
    public void OnCreate(ref SystemState state)
    {
        trackSegments =
            state.GetEntityQuery(ComponentType.ReadOnly<Segment>(), ComponentType.ReadOnly<LocalTransform>());
    }

    // Every function defined by ISystem has to be implemented even if empty.
    public void OnDestroy(ref SystemState state)
    {
    }

    // See note above regarding the [BurstCompile] attribute.
    public void OnUpdate(ref SystemState state)
    {
        var segments = trackSegments.ToComponentDataArray<LocalTransform>(Allocator.TempJob);
        var carMovementJob = new CarMovementJob
        {
            Segments = segments,
            DeltaTime = SystemAPI.Time.DeltaTime
        };

        carMovementJob.ScheduleParallel();
    }
}

[BurstCompile]
partial struct CarMovementJob : IJobEntity
{
    public NativeArray<LocalTransform> Segments;
    public float DeltaTime;

    private void Execute(Entity entity, ref CarData carData, ref LocalTransform transform)
    {
        var currentSegment = Segments[carData.SegmentID];
        var currentPosition = currentSegment;

        var targetSegment = carData.SegmentID + 1 < Segments.Length ? Segments[carData.SegmentID + 1] : Segments[0];
        var targetPosition = targetSegment;
        
        //Vector3.MoveTowards(car.transform.position, targetPosition, moveSpeed);

        var currentDistance = math.distance(transform.Position, targetPosition.Position);

        MoveTowards(transform.Position, targetPosition.Position, 100f * DeltaTime);

        if (currentDistance <= 0.25f)
        {
            carData.SegmentID = carData.SegmentID < Segments.Length - 1 ? carData.SegmentID + 1 : 0;
            // SystemAPI.SetComponent(entity, carData);
        }
    }
    
    public static float3 MoveTowards(float3 current, float3 target, float maxDistanceDelta)
    {
        float deltaX = target.x - current.x;
        float deltaY = target.y - current.y;
        float deltaZ = target.z - current.z;
        float sqdist = deltaX * deltaX + deltaY * deltaY  + deltaZ * deltaZ ;
        if (sqdist == 0 || sqdist <= maxDistanceDelta * maxDistanceDelta)
            return target;
        var dist = (float)math.sqrt(sqdist);
        return new float3(current.x + deltaX / dist * maxDistanceDelta,
            current.y + deltaY / dist * maxDistanceDelta,
            current.z + deltaZ / dist * maxDistanceDelta);
    }
}