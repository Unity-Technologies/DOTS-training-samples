using Unity.Entities;

public class SegmentAuthoring : UnityEngine.MonoBehaviour
{
    class SegmentBaker : Baker<SegmentAuthoring>
    {
        public override void Bake(SegmentAuthoring authoring)
        {
            AddComponent<Segment>();
        }
    }
}

public struct Segment : IComponentData
{
    
}
